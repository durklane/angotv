class AuthService {
  static bool isPremium = false; // Simula usuário premium ou grátis
}
